library(ggplot2)

## function for for the relationship between the ENC value and average GC3 frequency 
## for the case when mutation is the only force affecting GC3 content
wright <- function(gc3){
  return(2 + gc3 + (29/(gc3**2 + (1-gc3)**2)))
}

## plot the wright function
gc3s <- seq(0.01, 0.99, by = 0.01) # define a range of gc3 values for input into the wright function
encs <- wright(gc3s) # caclulate corresponding ENC values

plot(gc3s, encs)

## ggplot2 example for plotting the observed ENC value and
## the theoretical ENC expectation (based on Wright, 1990) on the same plot
data <- read.table("/Users/au612643/Desktop/friday/data.txt", header = TRUE) # load data
data$wright <- wright(data$GC3) # add a column to the data.frame with the theoretical expectation

p1 <- ggplot(data, aes(x = GC3)) + geom_point(aes(y = ENC, col = "blue")) + 
                                   geom_point(aes(y = wright, col = "red"))
p1

## alternative example for plotting an arbitrary range of values for the theoretical expectation
p2 <- ggplot() + geom_point(aes(x = data$GC3, y = data$ENC, col = "blue")) + 
                 geom_point(aes(x = seq(0.01, 0.99, by = 0.01), y = wright(seq(0.01, 0.99, by = 0.01)), col = "red"))
p2

